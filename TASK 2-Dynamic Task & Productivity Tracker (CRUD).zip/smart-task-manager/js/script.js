'use strict';

/* ---------- Config & State ---------- */
const STORAGE_KEY = 'smart-task-manager:tasks';
const THEME_KEY = 'smart-task-manager:theme';
const SORT_KEY = 'smart-task-manager:sort';
const CATEGORIES = {
  Work: '#4f6df5', Personal: '#a855f7', Study: '#0ea5e9',
  Shopping: '#f59e0b', Health: '#10b981', Others: '#64748b'
};
const PRIORITIES = { High: 3, Medium: 2, Low: 1 };
const state = { tasks: [], filter: 'all', view: 'all', category: 'all', query: '', sortMode: 'due' };
let editingId = null, pendingDeleteId = null, dragId = null, poppedId = null;

const $ = (id) => document.getElementById(id);
const esc = (s) => s.replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

/* ---------- Date helpers ---------- */
const pad = (n) => String(n).padStart(2, '0');
const toISO = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const todayISO = () => toISO(new Date());
const fmtDate = (iso) => new Date(iso + 'T00:00:00').toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' });
const isOverdue = (t) => !t.completed && !!t.due && t.due < todayISO();
const isToday = (t) => t.due === todayISO();
const isUpcoming = (t) => !t.completed && !!t.due && t.due > todayISO();

/* ---------- Persistence ---------- */
function saveToLocalStorage() {
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(state.tasks)); }
  catch (e) { toast('Could not save – browser storage is unavailable'); }
}

function loadFromLocalStorage() {
  try {
    const data = JSON.parse(localStorage.getItem(STORAGE_KEY));
    if (!Array.isArray(data)) return [];
    return data
      .filter((t) => t && typeof t.id === 'string' && typeof t.title === 'string' && t.title.trim())
      .map((t, i) => ({
        id: t.id, title: t.title.trim(), description: String(t.description || ''),
        category: CATEGORIES[t.category] ? t.category : 'Others',
        priority: PRIORITIES[t.priority] ? t.priority : 'Medium',
        due: /^\d{4}-\d{2}-\d{2}$/.test(t.due) ? t.due : '',
        completed: !!t.completed, createdAt: t.createdAt || new Date().toISOString(),
        order: Number.isFinite(t.order) ? t.order : i
      }));
  } catch (e) { return []; }
}

/* ---------- CRUD ---------- */
function validate({ title, due }) {
  if (!title.trim()) return 'Enter a task title.';
  if (title.trim().length < 2) return 'Title needs at least 2 characters.';
  if (due && isNaN(new Date(due + 'T00:00:00'))) return 'Choose a valid due date.';
  return '';
}

function addTask({ title, description = '', category = 'Others', due = '', priority = 'Medium' }) {
  const error = validate({ title, due });
  if (error) return error;
  const minOrder = state.tasks.reduce((m, t) => Math.min(m, t.order), 0);
  state.tasks.push({
    id: crypto.randomUUID ? crypto.randomUUID() : String(Date.now() + Math.random()),
    title: title.trim(), description: description.trim(), category, due, priority,
    completed: false, createdAt: new Date().toISOString(), order: minOrder - 1
  });
  commit('Task added');
  return '';
}

function editTask(id, { title, description = '', category, due = '', priority = 'Medium' }) {
  const error = validate({ title, due });
  if (error) return error;
  const t = state.tasks.find((x) => x.id === id);
  if (!t) return 'Task not found.';
  Object.assign(t, { title: title.trim(), description: description.trim(), category, due, priority });
  commit('Task updated');
  return '';
}

function deleteTask(id) {
  state.tasks = state.tasks.filter((t) => t.id !== id);
  commit('Task deleted');
}

function toggleTaskStatus(id) {
  const t = state.tasks.find((x) => x.id === id);
  if (!t) return;
  t.completed = !t.completed;
  poppedId = t.completed ? id : null;
  commit(t.completed ? 'Nice work – task completed' : 'Task marked active');
}

function commit(message) {
  saveToLocalStorage();
  renderAll();
  if (message) toast(message);
}

/* ---------- Filter / search / sort ---------- */
function searchTasks(list) {
  const q = state.query.trim().toLowerCase();
  return q ? list.filter((t) => t.title.toLowerCase().includes(q) || t.description.toLowerCase().includes(q)) : list;
}

function filterTasks() {
  let list = state.tasks;
  if (state.category !== 'all') list = list.filter((t) => t.category === state.category);
  if (state.view === 'today') list = list.filter(isToday);
  if (state.view === 'upcoming') list = list.filter(isUpcoming);
  if (state.filter === 'active') list = list.filter((t) => !t.completed);
  if (state.filter === 'completed') list = list.filter((t) => t.completed);
  if (state.filter === 'overdue') list = list.filter(isOverdue);
  return searchTasks(list);
}

function sortTasks(list) {
  const arr = [...list];
  if (state.sortMode === 'manual') return arr.sort((a, b) => a.order - b.order);
  return arr.sort((a, b) =>
    (a.completed - b.completed) ||
    (a.due || '9999').localeCompare(b.due || '9999') ||
    (PRIORITIES[b.priority] - PRIORITIES[a.priority]) ||
    a.order - b.order);
}

/* ---------- Rendering ---------- */
function updateDashboardStats() {
  const total = state.tasks.length;
  const done = state.tasks.filter((t) => t.completed).length;
  const pct = total ? Math.round((done / total) * 100) : 0;
  $('statTotal').textContent = total;
  $('statDone').textContent = done;
  $('statPending').textContent = total - done;
  $('statOver').textContent = state.tasks.filter(isOverdue).length;
  $('statPct').textContent = pct + '%';
  $('barFill').style.width = pct + '%';
  $('barWrap').setAttribute('aria-valuenow', pct);
  $('navToday').textContent = state.tasks.filter((t) => !t.completed && isToday(t)).length;
  $('navUpcoming').textContent = state.tasks.filter(isUpcoming).length;
  $('allDone').hidden = !(total > 0 && done === total);
}

function dueLabel(t) {
  if (!t.due) return '';
  if (t.completed) return `<span class="pill ok">✓ Done · due ${fmtDate(t.due)}</span>`;
  if (isOverdue(t)) return `<span class="pill bad">Overdue · ${fmtDate(t.due)}</span>`;
  if (isToday(t)) return '<span class="pill today">Due today</span>';
  return `<span class="pill">Due ${fmtDate(t.due)}</span>`;
}

function cardHTML(t) {
  return `<article class="card ${t.completed ? 'done' : ''} ${isOverdue(t) ? 'overdue' : ''} ${t.id === poppedId ? 'pop' : ''}"
      draggable="true" data-id="${t.id}" style="--c:${CATEGORIES[t.category]}">
    <div class="card-top">
      <input type="checkbox" class="check" ${t.completed ? 'checked' : ''} aria-label="Mark ${esc(t.title)} as ${t.completed ? 'active' : 'completed'}">
      <div><h3>${esc(t.title)}</h3>${t.description ? `<p>${esc(t.description)}</p>` : ''}</div>
    </div>
    <div class="meta">
      <span class="tag">${t.category}</span><span class="pill pri-${t.priority}">${t.priority}</span>${dueLabel(t)}
      <span class="pill">Created ${fmtDate(toISO(new Date(t.createdAt)))}</span>
      <div class="card-actions">
        <button class="edit" aria-label="Edit task" title="Edit">✎</button>
        <button class="del" aria-label="Delete task" title="Delete">🗑</button>
      </div>
    </div>
  </article>`;
}

const EMPTY_SVG = `<svg viewBox="0 0 160 120" fill="none"><rect x="30" y="18" width="100" height="84" rx="14" fill="var(--accent-soft)"/><rect x="46" y="38" width="22" height="22" rx="7" stroke="var(--accent)" stroke-width="3"/><rect x="76" y="42" width="40" height="6" rx="3" fill="var(--accent)" opacity=".5"/><rect x="76" y="54" width="26" height="6" rx="3" fill="var(--accent)" opacity=".3"/><path d="M50 82l6 6 12-12" stroke="var(--ok)" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/></svg>`;

function groupHTML(title, list) {
  return list.length ? `<h2 class="group-title">${title}<small>${list.length}</small></h2><div class="grid">${list.map(cardHTML).join('')}</div>` : '';
}

function renderTasks() {
  const list = sortTasks(filterTasks());
  const area = $('taskArea');
  if (!list.length) {
    const hasAny = state.tasks.length > 0;
    area.innerHTML = `<div class="empty">${EMPTY_SVG}<h3>${hasAny ? 'No tasks match' : 'Nothing here yet'}</h3>
      <p>${hasAny ? 'Try a different filter or search term.' : 'Add your first task above to get started.'}</p></div>`;
    return;
  }
  // On the main dashboard, pull today's tasks into their own section.
  const split = state.view === 'all' && state.filter !== 'completed' && state.sortMode === 'due';
  const todays = split ? list.filter((t) => !t.completed && isToday(t)) : [];
  const rest = split ? list.filter((t) => !todays.includes(t)) : list;
  area.innerHTML = groupHTML('Due today', todays) + groupHTML(todays.length ? 'Everything else' : 'Tasks', rest);
  poppedId = null;
}

function renderCategories() {
  $('catNav').innerHTML =
    `<button class="nav-item ${state.category === 'all' ? 'active' : ''}" data-cat="all"><span class="dot" style="--c:#fff"></span>All categories</button>` +
    Object.entries(CATEGORIES).map(([name, color]) => {
      const n = state.tasks.filter((t) => t.category === name && !t.completed).length;
      return `<button class="nav-item ${state.category === name ? 'active' : ''}" data-cat="${name}"><span class="dot" style="--c:${color}"></span>${name}<b>${n}</b></button>`;
    }).join('');
}

function renderAll() { updateDashboardStats(); renderCategories(); renderTasks(); }

/* ---------- UI helpers ---------- */
function toast(msg) {
  const el = document.createElement('div');
  el.className = 'toast'; el.textContent = msg;
  $('toasts').appendChild(el);
  setTimeout(() => { el.classList.add('out'); setTimeout(() => el.remove(), 300); }, 2400);
}

const openModal = (id) => { $(id).hidden = false; };
const closeModals = () => { document.querySelectorAll('.modal').forEach((m) => (m.hidden = true)); editingId = pendingDeleteId = null; };

function openTaskModal(id = null) {
  editingId = id;
  const t = id && state.tasks.find((x) => x.id === id);
  $('modalTitle').textContent = t ? 'Edit task' : 'New task';
  $('fSubmit').textContent = t ? 'Save changes' : 'Add task';
  $('fTitle').value = t ? t.title : '';
  $('fDesc').value = t ? t.description : '';
  $('fCat').value = t ? t.category : 'Work';
  $('fPri').value = t ? t.priority : 'Medium';
  $('fDue').value = t ? t.due : '';
  $('fErr').textContent = '';
  openModal('taskModal');
  $('fTitle').focus();
}

function applyTheme(theme) {
  document.documentElement.dataset.theme = theme;
  $('themeIcon').textContent = theme === 'dark' ? '☀' : '☾';
  $('themeText').textContent = theme === 'dark' ? 'Light mode' : 'Dark mode';
}

function setActive(containerId, attr, value) {
  document.querySelectorAll(`#${containerId} [${attr}]`).forEach((b) => b.classList.toggle('active', b.getAttribute(attr) === value));
}

/* ---------- Events ---------- */
function bindEvents() {
  const options = Object.keys(CATEGORIES).map((c) => `<option>${c}</option>`).join('');
  ['qCat', 'fCat'].forEach((id) => { $(id).innerHTML = options; });

  $('quickForm').addEventListener('submit', (e) => {
    e.preventDefault();
    const err = addTask({ title: $('qTitle').value, category: $('qCat').value, due: $('qDue').value });
    $('qErr').textContent = err;
    if (!err) { $('qTitle').value = ''; $('qDue').value = ''; }
  });

  $('taskForm').addEventListener('submit', (e) => {
    e.preventDefault();
    const data = { title: $('fTitle').value, description: $('fDesc').value, category: $('fCat').value, due: $('fDue').value, priority: $('fPri').value };
    const err = editingId ? editTask(editingId, data) : addTask(data);
    $('fErr').textContent = err;
    if (!err) closeModals();
  });

  ['openAdd', 'fab'].forEach((id) => $(id).addEventListener('click', () => openTaskModal()));
  document.querySelectorAll('[data-close]').forEach((b) => b.addEventListener('click', closeModals));
  document.querySelectorAll('.modal').forEach((m) => m.addEventListener('mousedown', (e) => { if (e.target === m) closeModals(); }));
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') { closeModals(); toggleSidebar(false); } });

  $('confirmYes').addEventListener('click', () => { if (pendingDeleteId) deleteTask(pendingDeleteId); closeModals(); });

  $('searchInput').addEventListener('input', (e) => { state.query = e.target.value; renderTasks(); });

  $('filterChips').addEventListener('click', (e) => {
    const b = e.target.closest('[data-filter]'); if (!b) return;
    state.filter = b.dataset.filter; setActive('filterChips', 'data-filter', state.filter); renderTasks();
  });
  $('viewNav').addEventListener('click', (e) => {
    const b = e.target.closest('[data-view]'); if (!b) return;
    state.view = b.dataset.view; setActive('viewNav', 'data-view', state.view); renderTasks(); toggleSidebar(false);
  });
  $('catNav').addEventListener('click', (e) => {
    const b = e.target.closest('[data-cat]'); if (!b) return;
    state.category = b.dataset.cat; renderAll(); toggleSidebar(false);
  });

  $('sortSelect').addEventListener('change', (e) => {
    state.sortMode = e.target.value; localStorage.setItem(SORT_KEY, state.sortMode); renderTasks();
  });

  $('themeToggle').addEventListener('click', () => {
    const next = document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark';
    applyTheme(next);
    try { localStorage.setItem(THEME_KEY, next); } catch (e) { /* ignore */ }
  });

  $('menuBtn').addEventListener('click', () => toggleSidebar(true));
  $('scrim').addEventListener('click', () => toggleSidebar(false));

  // Card actions (event delegation)
  const area = $('taskArea');
  area.addEventListener('click', (e) => {
    const card = e.target.closest('.card'); if (!card) return;
    const id = card.dataset.id;
    if (e.target.closest('.edit')) openTaskModal(id);
    else if (e.target.closest('.del')) {
      pendingDeleteId = id;
      $('confirmText').textContent = `“${state.tasks.find((t) => t.id === id).title}” will be removed permanently.`;
      openModal('confirmModal');
    }
  });
  area.addEventListener('change', (e) => {
    if (e.target.classList.contains('check')) toggleTaskStatus(e.target.closest('.card').dataset.id);
  });

  // Drag & drop reordering
  area.addEventListener('dragstart', (e) => {
    const card = e.target.closest('.card'); if (!card) return;
    dragId = card.dataset.id; card.classList.add('dragging'); e.dataTransfer.effectAllowed = 'move';
  });
  area.addEventListener('dragend', () => { dragId = null; area.querySelectorAll('.dragging,.over-target').forEach((c) => c.classList.remove('dragging', 'over-target')); });
  area.addEventListener('dragover', (e) => {
    const card = e.target.closest('.card'); if (!card || !dragId) return;
    e.preventDefault();
    area.querySelectorAll('.over-target').forEach((c) => c.classList.remove('over-target'));
    if (card.dataset.id !== dragId) card.classList.add('over-target');
  });
  area.addEventListener('drop', (e) => {
    const card = e.target.closest('.card'); if (!card || !dragId || card.dataset.id === dragId) return;
    e.preventDefault(); reorder(dragId, card.dataset.id);
  });
}

function reorder(fromId, toId) {
  // Start from what the user currently sees, then move the dragged task before the target.
  const ordered = sortTasks(state.tasks);
  const from = ordered.findIndex((t) => t.id === fromId);
  const [moved] = ordered.splice(from, 1);
  ordered.splice(ordered.findIndex((t) => t.id === toId), 0, moved);
  ordered.forEach((t, i) => { t.order = i; });
  state.sortMode = 'manual'; $('sortSelect').value = 'manual';
  localStorage.setItem(SORT_KEY, 'manual');
  commit('Order updated');
}

function toggleSidebar(open) {
  $('sidebar').classList.toggle('open', open);
  $('scrim').classList.toggle('show', open);
}

/* ---------- Init ---------- */
function init() {
  let theme = 'light';
  try {
    theme = localStorage.getItem(THEME_KEY) || 'dark';
    state.sortMode = localStorage.getItem(SORT_KEY) === 'manual' ? 'manual' : 'due';
  } catch (e) { /* storage blocked */ }
  applyTheme(theme);
  $('sortSelect').value = state.sortMode;
  const h = new Date().getHours();
  $('greeting').textContent = `Good ${h < 12 ? 'morning' : h < 18 ? 'afternoon' : 'evening'}`;
  $('dateLine').textContent = new Date().toLocaleDateString(undefined, { weekday: 'long', day: 'numeric', month: 'long' });
  state.tasks = loadFromLocalStorage();
  bindEvents();
  initExtras();
  renderAll();
}

/* ---------- Advanced: priority, focus timer, backup, shortcuts ---------- */
function initExtras() {
  $('fPri').innerHTML = Object.keys(PRIORITIES).map((p) => `<option>${p}</option>`).join('');
  $('fPri').value = 'Medium';

  // Focus timer (25 min)
  const TOTAL = 25 * 60; let left = TOTAL, timer = null;
  const draw = () => {
    $('tTime').textContent = `${pad(Math.floor(left / 60))}:${pad(left % 60)}`;
    $('tBar').style.width = ((TOTAL - left) / TOTAL) * 100 + '%';
  };
  $('tStart').addEventListener('click', () => {
    if (timer) { clearInterval(timer); timer = null; $('tStart').textContent = 'Resume'; return; }
    $('tStart').textContent = 'Pause';
    timer = setInterval(() => {
      left--; draw();
      if (left <= 0) { clearInterval(timer); timer = null; left = TOTAL; draw(); $('tStart').textContent = 'Start'; toast('Focus session complete – take a break'); }
    }, 1000);
  });
  $('tReset').addEventListener('click', () => { clearInterval(timer); timer = null; left = TOTAL; draw(); $('tStart').textContent = 'Start'; });

  // Export / import backup
  $('exportBtn').addEventListener('click', () => {
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([JSON.stringify(state.tasks, null, 2)], { type: 'application/json' }));
    a.download = `taskly-backup-${todayISO()}.json`; a.click(); URL.revokeObjectURL(a.href);
    toast('Backup exported');
  });
  $('importBtn').addEventListener('click', () => $('importFile').click());
  $('importFile').addEventListener('change', (e) => {
    const file = e.target.files[0]; if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        if (!Array.isArray(JSON.parse(reader.result))) throw new Error();
        localStorage.setItem(STORAGE_KEY, reader.result);
        state.tasks = loadFromLocalStorage(); saveToLocalStorage(); commit(`Imported ${state.tasks.length} tasks`);
      } catch (err) { toast('Import failed – not a valid backup file'); }
    };
    reader.readAsText(file); e.target.value = '';
  });

  // Keyboard shortcuts: N new task, / search, T theme
  document.addEventListener('keydown', (e) => {
    if (e.ctrlKey || e.metaKey || e.altKey || /INPUT|TEXTAREA|SELECT/.test(e.target.tagName) || document.querySelector('.modal:not([hidden])')) return;
    if (e.key === 'n') { e.preventDefault(); openTaskModal(); }
    else if (e.key === '/') { e.preventDefault(); $('searchInput').focus(); }
    else if (e.key === 't') $('themeToggle').click();
  });
}

document.addEventListener('DOMContentLoaded', init);
