'use strict';
/* ShopSphere – vanilla JS storefront */
const API = 'https://fakestoreapi.com/products';
const USD_TO_INR = 83;
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const store = {
  get: (k, d) => { try { return JSON.parse(localStorage.getItem(k)) ?? d; } catch { return d; } },
  set: (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch {} }
};
const inr = n => new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', minimumFractionDigits: 0, maximumFractionDigits: 2 }).format(n);
const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const catName = c => c === 'jewelery' ? 'Jewelry' : c;

const state = {
  products: [], cart: store.get('ss_cart', []), wish: store.get('ss_wish', []),
  cat: 'all', q: '', sort: '', wishOnly: false, max: Infinity, shown: 24, list: []
};
const PAGE = 24;
const EDITIONS = ['Classic', 'Pro', 'Lite', 'Max', 'Elite', 'Studio', 'Urban', 'Signature', 'Select', 'Prime'];
/* FakeStoreAPI has 20 items: build 200 by adding 9 editions of each (deterministic prices, ratings, discounts) */
function expand(base) {
  const out = [];
  EDITIONS.forEach((ed, e) => base.forEach((p, i) => {
    const k = e * base.length + i, r = ((k * 9301 + 49297) % 233280) / 233280;
    const mult = e === 0 ? 1 : .75 + ((k * 37) % 60) / 100;
    const inrP = e === 0 ? Math.round(p.price * USD_TO_INR) : Math.max(199, Math.round(p.price * USD_TO_INR * mult / 10) * 10);
    out.push({ ...p, id: k + 1, title: e === 0 ? p.title : `${p.title} – ${ed} Edition`, inr: inrP,
      mrp: Math.round(inrP * (1.1 + r * .35) / 10) * 10,
      rating: { rate: Math.min(5, Math.max(3.2, +(p.rating.rate + (r - .5) * 1.2).toFixed(1))), count: Math.max(12, Math.round(p.rating.count * (.4 + r * 1.2))) } });
  }));
  return out.sort((a, b) => ((a.id * 7919) % 211) - ((b.id * 7919) % 211));
}

/* ---------- icons ---------- */
const ICONS = {
  search: '<circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>',
  cart: '<circle cx="8" cy="21" r="1"/><circle cx="19" cy="21" r="1"/><path d="M2 2h2l2.7 12.4a2 2 0 0 0 2 1.6h9.8a2 2 0 0 0 2-1.6L22 7H5"/>',
  heart: '<path d="M19 14c1.5-1.5 3-3.2 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.8 0-3 .5-4.5 2-1.5-1.5-2.7-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4 3 5.5l7 7Z"/>',
  menu: '<path d="M4 6h16M4 12h16M4 18h16"/>', x: '<path d="M18 6 6 18M6 6l12 12"/>',
  eye: '<path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/>',
  plus: '<path d="M5 12h14M12 5v14"/>', minus: '<path d="M5 12h14"/>',
  trash: '<path d="M3 6h18M8 6V4h8v2M19 6l-1 14H6L5 6"/>',
  truck: '<path d="M1 3h15v13H1zM16 8h4l3 3v5h-7z"/><circle cx="5.5" cy="18.5" r="2"/><circle cx="18.5" cy="18.5" r="2"/>',
  shield: '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>',
  award: '<circle cx="12" cy="8" r="6"/><path d="m8.2 13.9-1.2 8.1 5-3 5 3-1.2-8.1"/>',
  refresh: '<path d="M3 12a9 9 0 0 1 15-6.7L21 8M21 3v5h-5M21 12a9 9 0 0 1-15 6.7L3 16M3 21v-5h5"/>',
  check: '<path d="M20 6 9 17l-5-5"/>', moon: '<path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/>', arrowup: '<path d="M12 19V5M5 12l7-7 7 7"/>'
};
const svg = n => `<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICONS[n]}</svg>`;
const icons = (root = document) => $$('i[data-i]', root).forEach(i => i.replaceWith(Object.assign(document.createElement('span'), { innerHTML: svg(i.dataset.i), style: 'display:contents' })));

/* ---------- helpers ---------- */
const stars = r => { const n = Math.round(r); return '★'.repeat(n) + '☆'.repeat(5 - n); };
const badgeFor = p => p.rating.rate >= 4.5 ? 'BEST SELLER' : p.rating.count >= 300 ? 'TRENDING' : 'NEW';
const find = id => state.products.find(p => p.id === id);
const lock = on => document.body.classList.toggle('lock', on);

function toast(msg) {
  const t = document.createElement('div');
  t.className = 'toast'; t.innerHTML = svg('check') + `<span>${esc(msg)}</span>`;
  $('#toasts').append(t); setTimeout(() => t.remove(), 2600);
}
function bump(el) { el.classList.remove('bump'); void el.offsetWidth; el.classList.add('bump'); }

/* ---------- products ---------- */
function showSkeletons() { $('#grid').innerHTML = '<div class="sk"></div>'.repeat(8); }

async function fetchProducts() {
  showSkeletons(); $('#resultInfo').textContent = '';
  try {
    const res = await fetch(API);
    if (!res.ok) throw new Error('HTTP ' + res.status);
    const data = await res.json();
    state.products = expand(data);
    const cap = Math.ceil(Math.max(...state.products.map(p => p.inr)) / 1000) * 1000;
    state.cap = state.max = cap; const pr = $('#price'); pr.max = cap; pr.value = cap; $('#maxVal').textContent = inr(cap);
    const hero = state.products.find(p => p.category === "men's clothing") || state.products[0];
    $('#heroCard').innerHTML = `<img src="${hero.image}" alt="${esc(hero.title)}">`;
    applyFilters();
  } catch (err) {
    console.error(err);
    $('#grid').innerHTML = `<div class="state"><h3>We couldn't load products</h3><p>Check your internet connection, then try again.</p><button class="btn dark" data-act="retry">Try again</button></div>`;
  }
}

function searchProducts(list, q) {
  q = q.trim().toLowerCase();
  return q ? list.filter(p => p.title.toLowerCase().includes(q)) : list;
}
function filterProducts(list) {
  if (state.cat !== 'all') list = list.filter(p => p.category === state.cat);
  if (state.wishOnly) list = list.filter(p => state.wish.includes(p.id));
  list = list.filter(p => p.inr <= state.max);
  return list;
}
function sortProducts(list) {
  const l = [...list];
  if (state.sort === 'low') l.sort((a, b) => a.inr - b.inr);
  if (state.sort === 'high') l.sort((a, b) => b.inr - a.inr);
  if (state.sort === 'rating') l.sort((a, b) => b.rating.rate - a.rating.rate);
  return l;
}
function applyFilters() {
  const list = sortProducts(searchProducts(filterProducts(state.products), state.q));
  displayProducts(list);
  $$('.chip').forEach(c => c.classList.toggle('on', c.dataset.cat === state.cat));
  $('#wishBtn').classList.toggle('on', state.wishOnly);
  $('#resultInfo').textContent = `${list.length} product${list.length === 1 ? '' : 's'}${state.wishOnly ? ' in your wishlist' : ''}`;
}

function displayProducts(l) { state.list = l; state.shown = PAGE; renderGrid(); }
function loadMore() { state.shown += PAGE; renderGrid(); }
function renderGrid() {
  const list = state.list.slice(0, state.shown), grid = $('#grid');
  const left = state.list.length - list.length;
  $('#more').hidden = left <= 0; $('#moreBtn').textContent = `Load more (${left} left)`;
  if (!state.list.length) {
    grid.innerHTML = `<div class="state"><h3>No products found</h3><p>Try a different search or clear your filters.</p><button class="btn dark" data-act="clear">Clear Filters</button></div>`;
    return;
  }
  grid.innerHTML = list.map(p => {
    const b = badgeFor(p), w = state.wish.includes(p.id);
    return `<article class="pc">
      <div class="pimg"><img src="${p.image}" alt="${esc(p.title)}" loading="lazy"><span class="badge ${b.split(' ')[0]}">${b}</span>
        <button class="heart ${w ? 'on' : ''}" data-act="wish" data-id="${p.id}" aria-label="Toggle wishlist" aria-pressed="${w}">${svg('heart')}</button></div>
      <div class="pb"><span class="cat-l">${catName(p.category)}</span><h3 class="pt">${esc(p.title)}</h3>
        <div class="rate"><span class="stars">${stars(p.rating.rate)}</span> ${p.rating.rate} (${p.rating.count} reviews)</div>
        <div class="price">${inr(p.inr)} <s class="mrp">${inr(p.mrp)}</s> <em class="off">${Math.round((1 - p.inr / p.mrp) * 100)}% off</em></div>
        <div class="prow"><button class="add" data-act="add" data-id="${p.id}">Add to Cart</button>
        <button class="qv-b" data-act="view" data-id="${p.id}" aria-label="Quick view">${svg('eye')}</button></div></div></article>`;
  }).join('');
}

/* ---------- cart ---------- */
const saveCart = () => { store.set('ss_cart', state.cart); renderCart(); };

function addToCart(id, qty = 1) {
  const p = find(id); if (!p) return;
  const item = state.cart.find(i => i.id === id);
  if (item) item.qty += qty;
  else state.cart.push({ id, qty, title: p.title, image: p.image, inr: p.inr });
  saveCart(); toast(`Added to cart: ${p.title.slice(0, 28)}${p.title.length > 28 ? '…' : ''}`);
}
function removeFromCart(id) { state.cart = state.cart.filter(i => i.id !== id); saveCart(); }
function updateQuantity(id, delta) {
  const item = state.cart.find(i => i.id === id); if (!item) return;
  item.qty += delta;
  item.qty <= 0 ? removeFromCart(id) : saveCart();
}
function calculateTotal() {
  const subtotal = state.cart.reduce((s, i) => s + i.inr * i.qty, 0);
  const tax = subtotal * 0.05;
  const shipping = subtotal === 0 ? 0 : subtotal > 2000 ? 0 : 99;
  return { subtotal, tax, shipping, total: subtotal + tax + shipping };
}
const summaryRows = t => `<div class="row"><span>Subtotal</span><span>${inr(t.subtotal)}</span></div>
  <div class="row"><span>Tax (5%)</span><span>${inr(t.tax)}</span></div>
  <div class="row"><span>Shipping</span><span>${t.shipping ? inr(t.shipping) : '<b class="free">Free</b>'}</span></div>
  <div class="row t"><span>Total</span><span>${inr(t.total)}</span></div>`;

function renderCart() {
  const count = state.cart.reduce((s, i) => s + i.qty, 0);
  const cc = $('#cartCount'); cc.textContent = count; bump(cc);
  const wc = $('#wishCount'); wc.textContent = state.wish.length;
  const body = $('#cartItems'), foot = $('#cartFoot');
  if (!state.cart.length) {
    body.innerHTML = `<div class="empty"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round">${ICONS.cart}</svg><h3>Your cart is empty</h3><p>Add something you love and it will show up here.</p><button class="btn dark" data-close>Continue Shopping</button></div>`;
    foot.innerHTML = ''; return;
  }
  body.innerHTML = state.cart.map(i => `<div class="ci"><img src="${i.image}" alt="">
    <div><h4>${esc(i.title)}</h4><div class="pr">${inr(i.inr)}</div>
      <div class="qty"><button data-act="dec" data-id="${i.id}" aria-label="Decrease quantity">${svg('minus')}</button><span>${i.qty}</span><button data-act="inc" data-id="${i.id}" aria-label="Increase quantity">${svg('plus')}</button></div></div>
    <button class="ib rm" data-act="rm" data-id="${i.id}" aria-label="Remove item">${svg('trash')}</button></div>`).join('');
  foot.innerHTML = summaryRows(calculateTotal()) +
    `<button class="btn dark" data-act="checkout">Checkout</button><button class="btn ghost" data-close>Continue Shopping</button>`;
}

/* ---------- wishlist ---------- */
function addToWishlist(id) { if (!state.wish.includes(id)) state.wish.push(id); store.set('ss_wish', state.wish); }
function removeFromWishlist(id) { state.wish = state.wish.filter(w => w !== id); store.set('ss_wish', state.wish); }
function toggleWish(id, btn) {
  const had = state.wish.includes(id);
  had ? removeFromWishlist(id) : addToWishlist(id);
  toast(had ? 'Removed from wishlist' : 'Saved to wishlist');
  bump($('#wishCount')); $('#wishCount').textContent = state.wish.length;
  if (state.wishOnly) return applyFilters();
  $$(`.heart[data-id="${id}"]`).forEach(h => { h.classList.toggle('on', !had); h.classList.remove('pop'); void h.offsetWidth; h.classList.add('pop'); });
}

/* ---------- overlays ---------- */
function openLayer(el) { el.classList.add('open'); if (el.classList.contains('modal')) $('#overlay').classList.remove('open'); else $('#overlay').classList.add('open'); lock(true); }
function closeAll() { $$('.drawer,.modal,.overlay').forEach(e => e.classList.remove('open')); lock(false); }
const openCart = () => openLayer($('#drawer'));

function openQuickView(id) {
  const p = find(id); if (!p) return;
  let q = 1;
  $('#qvBody').innerHTML = `<div class="qv-g"><div class="qv-img"><img src="${p.image}" alt="${esc(p.title)}"></div>
    <div><span class="cat-l">${catName(p.category)}</span><h3>${esc(p.title)}</h3>
    <div class="rate"><span class="stars">${stars(p.rating.rate)}</span> ${p.rating.rate} (${p.rating.count} reviews)</div>
    <p class="d">${esc(p.description)}</p><div class="price">${inr(p.inr)}</div>
    <div class="qrow"><div class="qty"><button data-q="-1" aria-label="Decrease">${svg('minus')}</button><span id="qvQty">1</span><button data-q="1" aria-label="Increase">${svg('plus')}</button></div>
    <button class="add" id="qvAdd">Add to Cart</button></div></div></div>`;
  $$('[data-q]', $('#qvBody')).forEach(b => b.onclick = () => { q = Math.max(1, Math.min(20, q + +b.dataset.q)); $('#qvQty').textContent = q; });
  $('#qvAdd').onclick = () => { addToCart(id, q); closeAll(); };
  openLayer($('#quickView'));
}

/* ---------- checkout ---------- */
function openCheckout() {
  if (!state.cart.length) return toast('Your cart is empty');
  closeAll();
  $('#coForm').hidden = false; $('#coDone').hidden = true;
  $('#orderForm').reset(); $$('.err', $('#orderForm')).forEach(e => e.textContent = ''); $$('.bad').forEach(e => e.classList.remove('bad'));
  const t = calculateTotal();
  $('#coSummary').innerHTML = `<h4>Order summary</h4>` + state.cart.map(i => `<div class="sl"><span>${esc(i.title.slice(0, 32))}${i.title.length > 32 ? '…' : ''} × ${i.qty}</span><span>${inr(i.inr * i.qty)}</span></div>`).join('') + '<hr style="border:0;border-top:1px solid var(--bd);margin:12px 0">' + summaryRows(t);
  openLayer($('#checkout'));
}
function validateCheckout(form) {
  const v = Object.fromEntries(new FormData(form)); let ok = true;
  const rules = {
    name: x => x.trim().length >= 2 || 'Enter your full name',
    email: x => /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(x.trim()) || 'Enter a valid email address',
    phone: x => /^[6-9]\d{9}$/.test(x.replace(/[\s-]/g, '')) || 'Enter a 10-digit mobile number',
    address: x => x.trim().length >= 8 || 'Enter your full delivery address',
    city: x => x.trim().length >= 2 || 'Enter your city',
    pin: x => /^[1-9]\d{5}$/.test(x.trim()) || 'Enter a 6-digit PIN code'
  };
  for (const k in rules) {
    const r = rules[k](v[k] || ''), input = form.elements[k];
    input.classList.toggle('bad', r !== true);
    input.parentElement.querySelector('.err').textContent = r === true ? '' : r;
    if (r !== true) ok = false;
  }
  return ok ? v : null;
}
function completeOrder(customer) {
  const id = 'SS-' + Date.now().toString(36).toUpperCase().slice(-5) + Math.floor(1000 + Math.random() * 9000);
  const t = calculateTotal(), items = [...state.cart];
  state.cart = []; store.set('ss_cart', state.cart); renderCart();
  $('#coForm').hidden = true; const d = $('#coDone'); d.hidden = false;
  d.innerHTML = `<div class="done"><div class="tick">${svg('check')}</div><h3>Order confirmed</h3>
    <p class="muted">Thank you, ${esc(customer.name.split(' ')[0])}. A confirmation will be sent to ${esc(customer.email)}.</p>
    <div class="oid">Order ID: ${id}</div>
    <div class="sum">${items.map(i => `<div class="sl"><span>${esc(i.title.slice(0, 32))}${i.title.length > 32 ? '…' : ''} × ${i.qty}</span><span>${inr(i.inr * i.qty)}</span></div>`).join('')}<hr style="border:0;border-top:1px solid var(--bd);margin:12px 0">${summaryRows(t)}
    <p class="muted" style="font-size:.82rem;margin-top:10px">Delivering to ${esc(customer.address)}, ${esc(customer.city)} – ${esc(customer.pin)}</p></div>
    <button class="btn dark" data-close>Continue Shopping</button></div>`;
}

/* ---------- events ---------- */
function clearFilters() {
  Object.assign(state, { cat: 'all', q: '', sort: '', wishOnly: false });
  $('#search').value = ''; $('#sort').value = '';
  if (state.cap) { state.max = state.cap; $('#price').value = state.cap; $('#maxVal').textContent = inr(state.cap); }
  applyFilters();
}
function goShop(cat) {
  if (cat) { state.cat = cat; state.wishOnly = false; }
  applyFilters(); $('#shop').scrollIntoView({ behavior: 'smooth' });
}

document.addEventListener('click', e => {
  const t = e.target.closest('[data-act],[data-close],.chip,.cat');
  if (!t) return;
  if (t.hasAttribute('data-close')) return closeAll();
  if (t.matches('.chip')) { state.cat = t.dataset.cat; return applyFilters(); }
  if (t.matches('.cat')) return goShop(t.dataset.cat);
  const id = +t.dataset.id;
  switch (t.dataset.act) {
    case 'add': fly(t.closest('.pc')?.querySelector('img')); addToCart(id); t.classList.add('done'); t.textContent = 'Added ✓'; setTimeout(() => { t.classList.remove('done'); t.textContent = 'Add to Cart'; }, 1200); break;
    case 'view': openQuickView(id); break;
    case 'wish': toggleWish(id, t); break;
    case 'inc': updateQuantity(id, 1); break;
    case 'dec': updateQuantity(id, -1); break;
    case 'rm': removeFromCart(id); break;
    case 'checkout': openCheckout(); break;
    case 'retry': fetchProducts(); break;
    case 'clear': clearFilters(); break;
  }
});
$('#overlay').addEventListener('click', closeAll);
$$('.modal').forEach(m => m.addEventListener('mousedown', e => { if (e.target === m) closeAll(); }));
document.addEventListener('keydown', e => { if (e.key === 'Escape') closeAll(); });
$('#cartBtn').onclick = openCart;
$('#wishBtn').onclick = () => { state.wishOnly = !state.wishOnly; if (state.wishOnly) { state.cat = 'all'; toast(state.wish.length ? 'Showing your wishlist' : 'Your wishlist is empty'); } goShop(); };
$('#searchBtn').onclick = () => { $('#shop').scrollIntoView({ behavior: 'smooth' }); setTimeout(() => $('#search').focus(), 500); };
$('#search').addEventListener('input', e => { state.q = e.target.value; applyFilters(); });
$('#sort').addEventListener('change', e => { state.sort = e.target.value; applyFilters(); });
$('#clear').onclick = clearFilters;
$('#burger').onclick = () => $('#links').classList.toggle('open');
$('#links').addEventListener('click', () => $('#links').classList.remove('open'));
$('#orderForm').addEventListener('submit', e => { e.preventDefault(); const v = validateCheckout(e.target); if (v) completeOrder(v); });
$('#newsForm').addEventListener('submit', e => {
  e.preventDefault();
  const inp = $('#newsEmail'), err = $('#newsErr'), ok = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(inp.value.trim());
  err.className = 'err' + (ok ? ' good' : ''); err.textContent = ok ? 'You\'re subscribed. Welcome aboard!' : 'Enter a valid email address';
  if (ok) { inp.value = ''; toast('Subscribed to the newsletter'); }
});

/* navbar state, active link, scroll reveal */
const sections = ['home', 'shop', 'categories', 'about', 'contact'];
function onScroll() {
  $('#nav').classList.toggle('scrolled', scrollY > 10);
  let cur = 'home';
  sections.forEach(s => { const el = $('#' + s); if (el.getBoundingClientRect().top <= 120) cur = s; });
  if (innerHeight + scrollY >= document.body.offsetHeight - 4) cur = 'contact';
  $$('.links a').forEach(a => a.classList.toggle('active', a.getAttribute('href') === '#' + cur));
}
addEventListener('scroll', onScroll, { passive: true });
const io = new IntersectionObserver(es => es.forEach(en => { if (en.isIntersecting) { en.target.classList.add('in'); io.unobserve(en.target); } }), { threshold: .12 });
$$('.reveal').forEach(el => io.observe(el));

/* init */
icons(); $('#year').textContent = new Date().getFullYear();
renderCart(); onScroll(); fetchProducts();

/* ---------- extra interactions ---------- */
function fly(img) {
  if (!img) return;
  const a = img.getBoundingClientRect(), b = $('#cartBtn').getBoundingClientRect(), c = img.cloneNode();
  c.style.cssText = `position:fixed;z-index:300;left:${a.left}px;top:${a.top}px;width:${a.width}px;height:${a.height}px;object-fit:contain;pointer-events:none;border-radius:16px`;
  document.body.append(c);
  c.animate([{ transform: 'none', opacity: 1 }, { transform: `translate(${b.left - a.left + 10}px,${b.top - a.top}px) scale(.08)`, opacity: .3 }], { duration: 700, easing: 'cubic-bezier(.5,0,.8,.4)' }).onfinish = () => c.remove();
}
const setTheme = t => { document.documentElement.dataset.theme = t; store.set('ss_theme', t); };
setTheme(store.get('ss_theme', matchMedia('(prefers-color-scheme:dark)').matches ? 'dark' : 'light'));
$('#themeBtn').onclick = () => setTheme(document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark');
$('#price').addEventListener('input', e => { state.max = +e.target.value; $('#maxVal').textContent = inr(state.max); applyFilters(); });
$('#moreBtn').onclick = loadMore;
new IntersectionObserver(es => { if (es[0].isIntersecting && !$('#more').hidden) loadMore(); }, { rootMargin: '300px' }).observe($('#more'));
$('#top').onclick = () => scrollTo({ top: 0, behavior: 'smooth' });
addEventListener('scroll', () => {
  const h = document.documentElement; $('#prog').style.transform = `scaleX(${scrollY / (h.scrollHeight - innerHeight || 1)})`;
  $('#top').classList.toggle('show', scrollY > 600);
}, { passive: true });
$('#grid').addEventListener('mousemove', e => {
  const c = e.target.closest('.pc'); if (!c || matchMedia('(hover:none)').matches) return;
  const r = c.getBoundingClientRect(), x = (e.clientX - r.left) / r.width - .5, y = (e.clientY - r.top) / r.height - .5;
  c.style.setProperty('--rx', -y * 8 + 'deg'); c.style.setProperty('--ry', x * 8 + 'deg');
  c.style.setProperty('--mx', (x + .5) * 100 + '%'); c.style.setProperty('--my', (y + .5) * 100 + '%');
});
$('#grid').addEventListener('mouseout', e => { const c = e.target.closest('.pc'); if (c && !c.contains(e.relatedTarget)) { c.style.setProperty('--rx', '0deg'); c.style.setProperty('--ry', '0deg'); } });
$('.hero').addEventListener('mousemove', e => {
  const v = $('.hero-vis'); v.style.setProperty('--px', (e.clientX / innerWidth - .5) * 24 + 'px'); v.style.setProperty('--py', (e.clientY / innerHeight - .5) * 24 + 'px');
});
document.addEventListener('pointerdown', e => {
  const b = e.target.closest('.btn,.add'); if (!b) return;
  const r = b.getBoundingClientRect(), d = Math.max(r.width, r.height), s = document.createElement('span');
  s.className = 'rip'; s.style.cssText = `width:${d}px;height:${d}px;left:${e.clientX - r.left - d / 2}px;top:${e.clientY - r.top - d / 2}px`;
  b.append(s); setTimeout(() => s.remove(), 600);
});
const co = new IntersectionObserver(es => es.forEach(en => {
  if (!en.isIntersecting) return; co.unobserve(en.target);
  const el = en.target, to = +el.dataset.count, t0 = performance.now();
  (function f(t) { const k = Math.min(1, (t - t0) / 1400); el.textContent = Math.round(to * (1 - Math.pow(1 - k, 3))).toLocaleString('en-IN'); if (k < 1) requestAnimationFrame(f); })(t0);
}));
$$('[data-count]').forEach(el => co.observe(el));
