# ShopSphere

A modern e-commerce storefront built with HTML5, CSS3 and vanilla JavaScript. Products load live from [FakeStoreAPI](https://fakestoreapi.com/products); prices are converted to INR (USD × 83).

## Run in VS Code with Live Server
1. Install [VS Code](https://code.visualstudio.com/) and the **Live Server** extension (Ritwick Dey).
2. Open the `ShopSphere` folder: **File → Open Folder**.
3. Right-click `index.html` and choose **Open with Live Server** (or click **Go Live** in the status bar).
4. The site opens at `http://127.0.0.1:5500`. It needs an internet connection for the API and fonts.

## Features
Search, category filter, sort and clear filters working together · cart drawer with quantity controls, 5% tax and free shipping above ₹2,000 (else ₹99) · quick view modal · wishlist · simulated checkout with validation and order confirmation · LocalStorage persistence for cart and wishlist · skeleton, empty and error states · responsive layout.

## Structure
`index.html` · `css/style.css` · `js/script.js` · `assets/images/`
